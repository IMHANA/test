package repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import domain.Member;

public interface MemberRepository {

	void addMember(Member member);
	
	Member findByMember(Member member) throws Exception;
	
	public List<String> findIdAll();
}
